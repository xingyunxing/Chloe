﻿namespace Chloe
{
    public enum TypeKind
    {
        Primitive = 1,
        Complex = 2,
        Collection = 3
    }
}
