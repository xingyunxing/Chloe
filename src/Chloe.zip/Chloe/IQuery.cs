﻿namespace Chloe
{
    public interface IQuery
    {
        Type ElementType { get; }
    }
}
