﻿namespace Chloe
{
    public enum LockType
    {
        Unspecified = 0,
        NoLock = 1,
        UpdLock = 2
    }
}
