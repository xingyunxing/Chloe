﻿namespace Chloe.Query.QueryState
{
    class AggregateQueryState : QueryStateBase, IQueryState
    {
        public AggregateQueryState(QueryModel queryModel)
            : base(queryModel)
        {
        }
    }
}
