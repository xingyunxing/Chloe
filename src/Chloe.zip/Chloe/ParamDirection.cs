﻿namespace Chloe
{
    public enum ParamDirection
    {
        Input = 1,
        Output = 2,
        InputOutput = 3,
        ReturnValue = 6
    }
}
