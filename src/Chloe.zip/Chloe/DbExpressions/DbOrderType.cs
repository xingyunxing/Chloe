﻿
namespace Chloe.DbExpressions
{
    public enum DbOrderType
    {
        Asc,
        Desc
    }
}
