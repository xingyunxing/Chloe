﻿
namespace Chloe.DbExpressions
{
    public enum DbJoinType
    {
        InnerJoin,
        LeftJoin,
        RightJoin,
        FullJoin
    }
}
