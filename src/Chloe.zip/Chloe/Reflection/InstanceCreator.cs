﻿
namespace Chloe.Reflection
{
    public delegate object InstanceCreator(params object[] arguments);
}
