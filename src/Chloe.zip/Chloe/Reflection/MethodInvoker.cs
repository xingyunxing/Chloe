﻿
namespace Chloe.Reflection
{
    public delegate object MethodInvoker(object instance, params object[] parameters);
}
