﻿namespace Chloe.Reflection
{
    public delegate void MemberSetter(object instance, object value);
}
