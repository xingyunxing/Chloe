﻿
namespace Chloe.Reflection
{
    public delegate object MemberGetter(object instance);
}
