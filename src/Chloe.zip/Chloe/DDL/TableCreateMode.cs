﻿namespace Chloe.DDL
{
    public enum TableCreateMode
    {
        CreateIfNotExists = 1,
        CreateNew = 2,
        Create = 3
    }
}
